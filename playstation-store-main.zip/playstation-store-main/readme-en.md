<table align="right">
  <tr>
    <td>
      <a href="readme-en.md">🇺🇸 English</a>
    </td>
  </tr>
  <tr>
    <td>
      <a href="README.md">🇧🇷 Português</a>
    </td>
  </tr>
</table>

![luk4x-repo-status](https://img.shields.io/badge/Status-Finished-lightgrey?style=for-the-badge&logo=headspace&logoColor=green&color=lightgrey)
![luk4x-repo-license](https://img.shields.io/github/license/Luk4x/playstation-store?style=for-the-badge&logo=unlicense&logoColor=lightgrey)
# 🎮 PlayStation Store Project

<br>
<p align="center">
  <a href="#-project-video-presentation">Video</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-technologies-used">Technologies</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-about">About</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-some-highlights">Highlights</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-cloning-the-project">Cloning</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-contributor-contact">Contact</a>
</p>
<br>

## 📹 Project Video Presentation
<div align="center">
  <video src="https://user-images.githubusercontent.com/86276393/153721431-a5b6c30f-cdb9-4e04-a5be-2c65c1a437ea.mp4">
</div>
  
> **If the video has any errors, reload the page!**<br>
> Access the project online **[HERE](https://luk4x.github.io/playstation-store/)**

## 🚀 Technologies Used

-   [Javascript](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
-   [CSS](https://developer.mozilla.org/en-US/docs/Web/CSS)
-   [HTML](https://developer.mozilla.org/en-US/docs/Web/HTML)

## 📝 About

> Watching the video above and/or accessing the project online will help you understand the explanation!

PlayStation Store is a web application that simulates the storefront of an e-commerce of peripherals related to PlayStation 5.<br>
My main focus during development was to improve my semantics and judgment when dealing with HTML, and my mastery of CSS when using MediaQueries, flexbox and etc... to make the project work as well as possible.<br>
Using the services of [FormSubmit](https://formsubmit.co/), I also ended up developing a form that actually works in the application's support tab.

### 📌 Some Highlights

- Functional form;
- Responsiveness;
- Semantic HTML;
- CSS Flexbox;

## 📖 Cloning the Project

To clone and run this project on your computer, you just need [Git](https://git-scm.com/) to be previously installed.<br>
After that, in the terminal:

```bash
# Clone this repository with:
> git clone https://github.com/Luk4x/playstation-store.git

# Enter the repository with:
> cd playstation-store

# Run the project with:
> start index.html # For Windows users
> open index.html # For Linux/Mac users
```

## 🤝 Contributor Contact

<table border="2">
  <tr>
    <td align="center">
      <details>
        <summary>
          <b><a href="https://cursos.alura.com.br/vitrinedev/lucasmacielf">Vitrine.Dev</a> 🪟</b>
          <table>
            <tr>
              <td align="center">
                <a href="https://github.com/Luk4x">
                  <img src="https://avatars.githubusercontent.com/Luk4x" width="150px;" alt="Luk4x Github Photo"/>
                </a>
                <br>
                <a href="https://www.linkedin.com/in/lucasmacielf/">
                  <sub>
                    <b>Lucas Maciel</b>
                  </sub>
                </a>
              </td>
            </tr>
          </table>
        </summary>

| :placard: Vitrine.Dev | Lucas Maciel |
| -------------  | --- |
| :sparkles: Name        | **🎮 PlayStation Store**
| :label: Technologies | javascript, css, html
| :camera: Img         | <img src="https://user-images.githubusercontent.com/86276393/202927051-ff57fb68-2c4e-499a-a777-f580ba5aa2b1.png#vitrinedev" alt="vitrine.dev thumb" width="100%"/>

</details>
</td>
</tr>
</table>

<p align="right">
  <a href="#-playstation-store-project">Back to Top</a>
</p>
